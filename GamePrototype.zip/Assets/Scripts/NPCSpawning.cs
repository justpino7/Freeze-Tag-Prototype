using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCSpawning : MonoBehaviour
{
    public GameObject[] spawnPoints;
    public GameObject npcPrefab;
    public int numNPCsToSpawn = 10;

    private int numNPCsSpawned = 0;
    private List<int> usedSpawnPoints = new List<int>();

    private void Start()
    {
        SpawnNPCs();
    }

    private void SpawnNPCs()
    {
        if (numNPCsSpawned < numNPCsToSpawn)
        {
            // Choose a random unused spawn point
            int index;
            do
            {
                index = Random.Range(0, spawnPoints.Length);
            } while (usedSpawnPoints.Contains(index));
            usedSpawnPoints.Add(index);

            // Spawn NPC at chosen spawn point
            GameObject npc = Instantiate(npcPrefab, spawnPoints[index].transform.position, Quaternion.identity);

            numNPCsSpawned++;

            // Call SpawnNPCs() again to spawn the next NPC
            Invoke("SpawnNPCs", 0f);
        }
    }
}
