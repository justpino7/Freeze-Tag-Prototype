using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CoinUI : MonoBehaviour
{
    private TextMeshProUGUI coinScore;

    void Start()
    {
        coinScore = GetComponent<TextMeshProUGUI>();
    }

    public void UpdateCoinScore(CoinsCollected coinsCollected)
    {
        coinScore.text = coinsCollected.CoinQuantity.ToString();             // Changes the default text ("0") to the CoinQuantity variable from the CoinsCollected script
    }

}
