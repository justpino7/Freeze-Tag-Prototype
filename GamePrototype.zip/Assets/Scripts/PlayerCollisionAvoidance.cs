using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCollisionAvoidance : MonoBehaviour
{
    public float speed = 5.0f;
    public float avoidanceDistance = 2.0f;
    public float rayDistance = 5.0f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        // Get all colliders within a certain radius
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, avoidanceDistance);

        // Loop through all colliders to check for obstacles
        foreach (Collider hitCollider in hitColliders)
        {
            // Check if the collider is on the Wall layer
            if (hitCollider.gameObject.layer == LayerMask.NameToLayer("Wall"))
            {
                // Calculate the direction from the player to the obstacle
                Vector3 obstacleDirection = hitCollider.transform.position - transform.position;

                // Calculate the angle between the player's forward vector and the obstacle direction
                float angle = Vector3.Angle(transform.forward, obstacleDirection);

                // If the angle is less than 90 degrees, there is an obstacle in front of the player
                if (angle < 90.0f)
                {
                    // Cast a ray to see if there is a clear path to move
                    RaycastHit hit;
                    if (!Physics.Raycast(transform.position, obstacleDirection.normalized, out hit, rayDistance))
                    {
                        // If there is no obstacle in the way, move away from the obstacle
                        rb.AddForce(-obstacleDirection.normalized * speed);
                    }
                }
            }
        }
    }
}
