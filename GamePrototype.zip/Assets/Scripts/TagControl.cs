using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TagControl : MonoBehaviour
{
    void Start()
    {
        StartCoroutine(PickChaser());
    }

    void Update()
    {

        if (GameObject.FindGameObjectsWithTag("Frozen").Length == 10)       // 10 NPCs are loaded as per the requirements   
        {
            SceneManager.LoadScene(2);      // Game Over
        }

        if (GameObject.FindGameObjectsWithTag("Evader").Length == 0)
        {
            SceneManager.LoadScene(2);
        }
    }

    IEnumerator PickChaser()
    {
        yield return new WaitForSecondsRealtime(1.5f);      // wait a few seconds to make sure that all NPCs have spawned
        int index = Random.Range(0, 9);
        Debug.Log("Index is: " + index);
        GameObject.FindGameObjectsWithTag("Evader")[index].tag = "Chaser";
    }


}
