
using System.Collections.Generic;
using UnityEngine;
using NPC;

public class TagActor : MonoBehaviour
{
    public enum TagRole { Chase, Flee, Neutral, Frozen, Rescue };       // 5 different NPC roles

    private static int chaserIndex = 0;
    public static List<TagActor> frozenActors;
    public static List<TagActor> neutralActors;
    public static List<TagActor> actors;

    public TagRole tr;

    [SerializeField]
    Material chaserMat;

    [SerializeField]
    Material neutralMat;

    [SerializeField]
    MeshRenderer meshRenderer;

    [SerializeField]
    float chaserSpeedMod = 3f;

    [SerializeField]
    NPCAgent agent;

    [SerializeField]
    NPCMotion seek, flee, wander;


    private void Awake()
    {
        seek.supressed = true;
        flee.supressed = true;
        wander.supressed = false;

        if (neutralActors == null)
        {   
            neutralActors = new List<TagActor>();
        }
        if (frozenActors == null)
        {
            frozenActors = new List<TagActor>();
        }
        if (actors == null)
        {
            actors = new List<TagActor>();
        }
        actors.Add(this);
        chaserIndex = Random.Range(0, actors.Count - 1);
    }
    // Start is called before the first frame update
    void Start()
    {
        if (this == actors[chaserIndex])
        {
            SetRole(TagRole.Chase, transform);
            getNewChaserTarget();
            meshRenderer.material = chaserMat;
        }
        else
        {
            SetRole(TagRole.Neutral, transform);
            meshRenderer.material = neutralMat;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!agent.HasTrackedTarget && tr == TagRole.Rescue)
        {
            getNewRescueTarget();
        }
    }

    public void handleSensorIn (Collider other)
    {
        if (other.CompareTag("Player") && other.gameObject != this.gameObject)
        {
            print(gameObject + " sensing " + other.gameObject);
            if (tr == TagRole.Chase)
                getNewChaserTarget(other.GetComponent<TagActor>());
        }
            
    }

    private void getNewChaserTarget ()
    {
        bool chosen = false;
        foreach (TagActor actor in actors)
        {
            if (actor == this)
                continue;
            if (actor.tr != TagRole.Frozen)
            {
                actor.SetRole(TagRole.Flee, transform);
                agent.TrackTarget(actor.transform);
                chosen = true;
                return;
            }
        }

        if (!chosen)
            TagActor.ResetGame();
    }

    private void getNewChaserTarget(TagActor player)
    {
        if (player.tr != TagRole.Frozen)
        {
            //unset the current fleeing target
            foreach (TagActor p in actors)
            {
                if (p == this)
                    continue;
                if (p.tr == TagRole.Flee)
                {
                    p.SetRole(TagRole.Rescue, null);
                }
            }

            //set the new target
            player.SetRole(TagRole.Flee, transform);
            agent.TrackTarget(player.transform);
        }
    }

    private bool getNewRescueTarget ()
    {
        if (frozenActors.Count > 0)
        {
            agent.TrackTarget(frozenActors[0].transform);
            SetRole(TagRole.Rescue, null);
            return true;
        }
            
        else
            agent.TrackTarget(null);
        return false;
    }

    private void SetRole (TagRole r, Transform target)
    {
        if (tr == TagRole.Frozen)
        {
            frozenActors.Remove(this);
        }

        if (tr == TagRole.Flee)
        {
            agent.TrackTarget(null);
        }

        tr = r;
        print(gameObject + " role is now " + r);

        switch (r)
        {
            case TagRole.Chase:
                getNewChaserTarget();
                seek.supressed = false;
                flee.supressed = true;
                wander.supressed = true;
                agent.speed = chaserSpeedMod * agent.baseSpeed;
                agent.isFreezed = false;
                break;

            case TagRole.Flee:
                agent.TrackTarget(target);
                seek.supressed = true;
                flee.supressed = false;
                wander.supressed = false;
                agent.speed = agent.baseSpeed;
                agent.isFreezed = false;
                break;

            case TagRole.Frozen:
                agent.TrackTarget(null);
                seek.supressed = true;
                flee.supressed = true;
                wander.supressed = true;
                agent.speed = 0f;
                agent.isFreezed = true;
                frozenActors.Add(this);
                break;

            case TagRole.Neutral:
                if (getNewRescueTarget())
                    return;
                agent.TrackTarget(null);
                seek.supressed = true;
                flee.supressed = true;
                wander.supressed = false;
                agent.speed = agent.baseSpeed;
                agent.isFreezed = false;
                break;

            case TagRole.Rescue:
                seek.supressed = false;
                flee.supressed = true;
                wander.supressed = true;
                agent.speed = agent.baseSpeed;
                agent.isFreezed = false;
                break;
        }
                
    }

    public static void ResetGame()
    {
        TagActor lastTagged = frozenActors[frozenActors.Count - 1];
        chaserIndex = actors.IndexOf(lastTagged);

        frozenActors = new List<TagActor>();

        foreach (TagActor actor in actors)
        {
            if (actor == actors[chaserIndex])
            {
                actor.SetRole(TagRole.Chase, null);
                actor.meshRenderer.material = actor.chaserMat;
            }
            else
            {
                actor.SetRole(TagRole.Neutral, null);
                actor.meshRenderer.material = actor.neutralMat;
                actor.transform.position = new Vector3(Random.Range(-9f, 9f), 0.5f, Random.Range(-9f, 9f));
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            TagActor otherPlayer = other.GetComponent<TagActor>();
            if (tr == TagRole.Chase && otherPlayer.tr != TagRole.Frozen)
            {
                otherPlayer.SetRole(TagRole.Frozen, transform);
                getNewChaserTarget();
            }
            if (tr != TagRole.Chase && otherPlayer.tr == TagRole.Frozen)
            {
                otherPlayer.SetRole(TagRole.Neutral, null);
                this.SetRole(TagRole.Neutral, null);
            }
        }
    }


}
