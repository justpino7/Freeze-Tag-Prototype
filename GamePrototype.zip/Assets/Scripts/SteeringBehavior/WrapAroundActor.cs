// Wrap around idea inspired from youtube video
// Mainly used to test steering behaviors without having to deal with collision detection

using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class WrapAroundActor : MonoBehaviour
{
    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Respawn"))
        {
            transform.position = WrapAroundPlane.plane.GetWrapAroundPos(transform.position);
        }
    }
}
