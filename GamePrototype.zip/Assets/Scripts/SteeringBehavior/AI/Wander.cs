﻿using UnityEngine;


namespace NPC
{
    public class Wander : NPCMotion
    {
        public float wanderDegreesDelta = 45;
        [Min(0)] public float wanderInterval = 0.75f;
        protected float wanderTimer = 0;

        private Vector3 lastWanderDirection = Vector3.zero;
        private Vector3 lastDisplacement = Vector3.zero;

        public override SteeringOutput GetKinematic(NPCAgent agent)
        {
            var output = base.GetKinematic(agent);
            wanderTimer += Time.deltaTime;

            Vector3 desiredVelocity = output.linear;

            if (lastWanderDirection == Vector3.zero)
                lastWanderDirection = transform.forward.normalized * agent.speed;

            if (lastDisplacement == Vector3.zero)
                lastDisplacement = transform.forward;

            desiredVelocity = lastDisplacement;

            //if wander time has elapsed, get a new direction
            if (wanderTimer > wanderInterval)
            {
                float angle = (Random.value - Random.value) * wanderDegreesDelta;
                Vector3 direction = Quaternion.AngleAxis(angle, Vector3.up) * lastWanderDirection.normalized;
                Vector3 circleCenter = agent.transform.position + lastDisplacement;
                Vector3 destination = circleCenter + direction.normalized;
                desiredVelocity = destination - agent.transform.position;
                desiredVelocity = desiredVelocity.normalized * agent.speed;

                lastDisplacement = desiredVelocity;
                lastWanderDirection = direction;
                wanderTimer = 0f;
            }    

            output.linear = desiredVelocity;
			
			if (debug) Debug.DrawRay(transform.position, output.linear, Color.cyan);
			
            return output;
        }
    }
}
