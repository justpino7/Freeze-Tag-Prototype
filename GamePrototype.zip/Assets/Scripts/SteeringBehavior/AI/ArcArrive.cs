﻿using UnityEngine;


namespace NPC
{
    public class ArcArrive : NPCMotion
    {
        public float stationaryAngle;
        public float movingAngle;

        public float stopRadius;
        public float slowRadius;

        private void DrawDebug(NPCAgent agent)
        {
            if (debug)
            {
                if (agent.Velocity.magnitude > 0)
                {
                    Vector3 lineA = Quaternion.AngleAxis(-1 * movingAngle, Vector3.up) * agent.transform.forward * 5f;
                    Vector3 lineB = Quaternion.AngleAxis(movingAngle, Vector3.up) * agent.transform.forward * 5f;
                    Debug.DrawRay(transform.position, lineA, Color.green);
                    Debug.DrawRay(transform.position, lineB, Color.green);
                }
                else
                {
                    Vector3 lineA = Quaternion.AngleAxis(-1 * stationaryAngle, Vector3.up) * agent.transform.forward * 5f;
                    Vector3 lineB = Quaternion.AngleAxis(stationaryAngle, Vector3.up) * agent.transform.forward * 5f;
                    Debug.DrawRay(transform.position, lineA, Color.green);
                    Debug.DrawRay(transform.position, lineB, Color.green);
                }
            }
        }

        public override SteeringOutput GetKinematic(NPCAgent agent)
        {
            DrawDebug(agent);

            var output = base.GetKinematic(agent);

            Vector3 desiredVelocity = agent.TrackedPosition - agent.transform.position;
            float distance = desiredVelocity.magnitude;
            desiredVelocity = desiredVelocity.normalized * agent.speed;

            if (distance < stopRadius)
                return output;

            float currentAngle = agent.Velocity.magnitude > 0 ? movingAngle : stationaryAngle;

            if (!agent.isFacingTarget(currentAngle))
                desiredVelocity *= 0;

            Quaternion targetRotation = Quaternion.LookRotation(agent.TrackedPosition - agent.transform.position, Vector3.up);
            output.angular = Quaternion.Lerp(agent.transform.rotation, targetRotation, agent.turnInterval);

            output.linear = desiredVelocity;

            return output;
        }
    }
}
