﻿using UnityEngine;


namespace NPC
{
    public abstract class NPCMotion : MonoBehaviour
    {
        public bool supressed;
        public bool debug;

        public virtual SteeringOutput GetKinematic(NPCAgent agent)
        {
            return new SteeringOutput { angular = agent.transform.rotation };
        }
    }
}
