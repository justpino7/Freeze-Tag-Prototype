using UnityEngine;

namespace NPC
{
    public class NPCAgent : MonoBehaviour
    {

        public bool debugMode;
        public bool Ylock = true;
        public bool isFreezed = false;

        public float speed;
        public float baseSpeed;
        public float turnInterval;
        public float maxDegreesDelta;
        public float maxAngleDifference = 0.2f; //determines is facing

        public enum EBehaviorType { Kinematic, Steering }
        public EBehaviorType behaviorType;

        [SerializeField] private Transform trackedTarget;
        [SerializeField] private Vector3 targetPosition;
        public bool HasTrackedTarget
        {
            get => trackedTarget != null;
        }
        public Vector3 TrackedPosition
        {
            get => trackedTarget != null ? WrapAroundPlane.plane.getBestTargetPosition(transform.position, trackedTarget.position) : transform.position;
        }
        public Vector3 TrackedTargetForward
        {
            get => trackedTarget != null ? trackedTarget.forward : Vector3.forward;
        }
        public Vector3 TargetVelocity
        {
            get
            {
                Vector3 v = Vector3.zero;
                if (trackedTarget != null)
                {
                    NPCAgent targetAgent = trackedTarget.GetComponent<NPCAgent>();
                    if (targetAgent != null)
                        v = targetAgent.Velocity;
                }

                return v;
            }
        }

        public Vector3 Velocity { get; set; }

        public void TrackTarget(Transform targetTransform)
        {
            trackedTarget = targetTransform;
        }

        public void UnTrackTarget()
        {
            trackedTarget = null;
        }

        private void Awake()
        {
            speed = baseSpeed;
        }

        private void Update()
        {
            if (debugMode)
            {
                Debug.DrawRay(transform.position, Velocity, Color.red);
            }

            GetKinematicAvg(out Vector3 kinematicAvg, out Quaternion rotation);

            Velocity = kinematicAvg.normalized * speed;

            transform.position += Velocity * Time.deltaTime;

            transform.rotation = rotation;
            
        }

        private void GetKinematicAvg(out Vector3 kinematicAvg, out Quaternion rotation)
        {
            kinematicAvg = Vector3.zero;
            Vector3 eulerAvg = Vector3.zero;
            NPCMotion[] movements = GetComponents<NPCMotion>();
            int count = 0;
            foreach (NPCMotion movement in movements)
            {
                if (movement.supressed)
                    continue;

                kinematicAvg += movement.GetKinematic(this).linear;
                eulerAvg += movement.GetKinematic(this).angular.eulerAngles;

                ++count;
            }

            if (count > 0)
            {
                kinematicAvg /= count;
                eulerAvg /= count;
                rotation = Quaternion.Euler(eulerAvg);
            }
            else
            {
                kinematicAvg = Velocity;
                rotation = transform.rotation;
            }
        }

        public bool isFacingTarget ()
        {
            Vector3 directionToTarget = TrackedPosition - transform.position;

            return Mathf.Abs(Vector3.Angle(transform.forward, directionToTarget)) <= maxAngleDifference;
        }

        public bool isFacingTarget(float _angle)
        {
            Vector3 directionToTarget = TrackedPosition - transform.position;

            return Mathf.Abs(Vector3.Angle(transform.forward, directionToTarget)) <= _angle;
        }

        public bool isFacingAwayTarget()
        {
            Vector3 directionFromTarget = transform.position - TrackedPosition;

            return Mathf.Abs(Vector3.Angle(transform.forward, directionFromTarget)) <= maxAngleDifference;
        }
    }
}