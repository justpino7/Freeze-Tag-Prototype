﻿// Based from labs

using UnityEngine;


namespace NPC
{
    public class Arrive : NPCMotion
    {
        public float slowRadius;
        public float stopRadius;


        public override SteeringOutput GetKinematic(NPCAgent agent)
        {

            var output = base.GetKinematic(agent);

            Vector3 desiredVelocity = agent.TrackedPosition - agent.transform.position;
            float distance = desiredVelocity.magnitude;
            desiredVelocity = desiredVelocity.normalized * agent.speed;

            if (distance <= stopRadius)
                desiredVelocity *= 0;
            else if (distance < slowRadius)
                desiredVelocity *= (distance / slowRadius);
            else if (!agent.isFacingTarget())
            {
                desiredVelocity *= 0;

                Quaternion targetRotation = Quaternion.LookRotation(agent.TrackedPosition - agent.transform.position, Vector3.up);

                output.angular = Quaternion.Lerp(agent.transform.rotation, targetRotation, agent.turnInterval);
            }
            output.linear = desiredVelocity;

            return output;
        }

    }
}
