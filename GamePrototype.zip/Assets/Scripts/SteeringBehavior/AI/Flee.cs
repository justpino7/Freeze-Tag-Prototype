﻿// Based from labs


using UnityEngine;

namespace NPC
{
    public class Flee : NPCMotion
    {
        public float stepDistance;
        public float safeDistance;

        public override SteeringOutput GetKinematic(NPCAgent agent)
        {
            var output = base.GetKinematic(agent);

            Quaternion targetRotation;

            // TODO: calculate linear component
            Vector3 desiredVelocity = agent.transform.position - agent.TrackedPosition;
            float distance = desiredVelocity.magnitude;
            desiredVelocity = desiredVelocity.normalized * agent.speed;

            if (distance > safeDistance)
            {
                desiredVelocity *= 0;
            }

            else if (distance > stepDistance && !agent.isFacingAwayTarget())
            {
                desiredVelocity *= 0;

                targetRotation = Quaternion.LookRotation(agent.transform.position - agent.TrackedPosition, Vector3.up);

                output.angular = Quaternion.Lerp(agent.transform.rotation, targetRotation, agent.turnInterval);
            }

            targetRotation = Quaternion.LookRotation(agent.transform.position - agent.TrackedPosition, Vector3.up);
            output.angular = Quaternion.Lerp(agent.transform.rotation, targetRotation, agent.turnInterval);

            output.linear = desiredVelocity;

            if (debug) Debug.DrawRay(transform.position, output.linear, Color.cyan);
			
            return output;
        }
    }
}
