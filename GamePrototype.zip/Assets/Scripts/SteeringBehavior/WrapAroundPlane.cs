// Wrap around idea inspired from youtube video
// Mainly used to test steering behaviors without having to deal with collision detection

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WrapAroundPlane : MonoBehaviour
{
    private const float BASE_SIZE = 10f;

    private float scale;

    public static WrapAroundPlane plane;

    public Vector3 xOffset;
    public Vector3 zOffset;

    private void Awake()
    {
        plane = this;

        scale = transform.localScale.x;

        xOffset = new Vector3(BASE_SIZE * scale, 0f, 0f);
        zOffset = new Vector3(0f, 0f, BASE_SIZE * scale);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public Vector3 GetWrapAroundPos (Vector3 position)
    {
        Vector3 returnValue = position;

        if (position.x >= BASE_SIZE * scale / 2)
            returnValue -= xOffset;
        if (position.x <= -1 * BASE_SIZE * scale / 2)
            returnValue += xOffset;
        if (position.z >= BASE_SIZE * scale / 2)
            returnValue -= zOffset;
        if (position.z <= -1 * BASE_SIZE * scale / 2)
            returnValue += zOffset;

        return returnValue;

    }

    public Vector3 getBestDirectionToTarget(Vector3 position, Vector3 target)
    {
        Vector3 result = target - position;

        Vector3 topLeft, topMid, topRight, midLeft, midRight, botLeft, botMid, botRight;

        topLeft = target + zOffset - xOffset;
        topMid = target + zOffset;
        topRight = target + zOffset + xOffset;

        midLeft = target - xOffset;
        midRight = target + xOffset;

        botLeft = target - zOffset - xOffset;
        botMid = target - zOffset;
        botRight = target - zOffset + xOffset;

        if ((topLeft - position).magnitude < result.magnitude)
            result = topLeft - position;

        if ((topMid - position).magnitude < result.magnitude)
            result = topMid - position;

        if ((topRight - position).magnitude < result.magnitude)
            result = topRight - position;

        if ((midLeft - position).magnitude < result.magnitude)
            result = midLeft - position;

        if ((midRight - position).magnitude < result.magnitude)
            result = midRight - position;

        if ((botLeft - position).magnitude < result.magnitude)
            result = botLeft - position;

        if ((botMid - position).magnitude < result.magnitude)
            result = botMid - position;

        if ((botRight - position).magnitude < result.magnitude)
            result = botRight - position;

        return result;
    }

    public Vector3 getBestTargetPosition(Vector3 position, Vector3 target)
    {
        return position + getBestDirectionToTarget(position, target);
    }



}
