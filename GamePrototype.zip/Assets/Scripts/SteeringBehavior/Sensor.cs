
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sensor : MonoBehaviour
{

    [SerializeField] TagActor actor;

    private void OnTriggerEnter(Collider other)
    {
        actor.handleSensorIn(other);
    }
}
