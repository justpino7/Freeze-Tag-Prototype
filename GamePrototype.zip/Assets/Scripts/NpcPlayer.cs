using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using TMPro;

public class NpcPlayer : MonoBehaviour
{
    Animator animator;

    public Vector3 destination;
    public Vector3 velocity;
    float distance;
    public float speed;
    public float maxSpeed;
    public float satRadius;
    public float targetRadius;
    public float timeToTarget;
    public float rotationDegreesPerSecond;
    public string targetName;

    public bool arrive;
    public bool flee;
    public bool wander;

    public int timesFrozen;     // future implementation: if frozen more than once --> flocking
    public bool coinChaser = false;       // chase coin when true
    public float maxFreezeTime = 5.0f;

    public string currentTag;       // keeps track of the current tag

    // Material and Meshes to differentiate players
    public Material evaderMat;
    public Material chaserMat;
    public Material frozenMat;
    public Material coinChaserMat;

    public bool debug = true;

    private SkinnedMeshRenderer jointsRenderer;
    private SkinnedMeshRenderer surfaceRenderer;

    public TextMeshProUGUI chaserTokenScore;

    void Start()
    {
        satRadius = 5;
        timeToTarget = 0.5f;
        rotationDegreesPerSecond = 360;
        currentTag = gameObject.tag;
        animator = GetComponent<Animator>();

        jointsRenderer = transform.Find("Beta_Joints").GetComponent<SkinnedMeshRenderer>();
        surfaceRenderer = transform.Find("Beta_Surface").GetComponent<SkinnedMeshRenderer>();

    }

    void Update()
    {
        animator.SetFloat("Blend", speed / maxSpeed);   // NPC blended animation

        // Determine the boundaries for our freeze tag game (since no collision avoidance implemented)
        if (transform.position.x > 12)
        {
            transform.position = new Vector3(-12, transform.position.y, transform.position.z);
        }
        if (transform.position.x < -12)
        {
            transform.position = new Vector3(12, transform.position.y, transform.position.z);
        }
        if (transform.position.z > 12)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, -12);
        }
        if (transform.position.z < -12)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, 12);
        }

        // Set a target update the NPC color based on its tag
        if (this.tag == "Chaser")
        {            
            if (coinChaser)
            {
                UpdateMaterial();
                Target("Token");
                maxSpeed = 3;
                targetRadius = 15;
                transform.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
            } 
            else
            {
                UpdateMaterial();
                Target("Evader");
                maxSpeed = 8;          // must be faster than the max speed of evaders to make the game interesting
                targetRadius = 7;
                transform.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
            }
        }
        else if (this.tag == "Frozen")
        {
            UpdateMaterial();
            speed = 0;
            transform.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeAll;
            StartCoroutine(BecomeChaserTimer());
        }
        else
        {
            UpdateMaterial();
            Target("Frozen");
            maxSpeed = 1;
            targetRadius = 12;
            transform.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        }

        //Kinematic arrive
        if (arrive)
        {
            Vector3 velocity = destination - transform.position;
            if (velocity.magnitude < satRadius)
            {
                speed = 8;
            }
            velocity /= timeToTarget;
            if (velocity.magnitude > maxSpeed)
            {
                velocity.Normalize();
                velocity *= maxSpeed;
                speed = maxSpeed;
            }
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(velocity), rotationDegreesPerSecond * Time.deltaTime);
        }


        //Arc Arrive
        //if (arrive)
        //{
        //    Vector3 targetOffset = destination - transform.position;
        //    float distance = targetOffset.magnitude;
        //    float targetSpeed;

        //    if (distance < targetRadius)
        //    {
        //        targetSpeed = 0;
        //    }
        //    else
        //    {
        //        targetSpeed = maxSpeed * Mathf.Min(distance / satRadius, 1f);
        //    }

        //    Vector3 targetVelocity = targetOffset.normalized * targetSpeed;

        //    Vector3 acceleration = (targetVelocity - velocity) / timeToTarget;

        //    if (acceleration.magnitude > maxSpeed)
        //    {
        //        acceleration.Normalize();
        //        acceleration *= maxSpeed;
        //    }

        //    velocity += acceleration * Time.deltaTime;
        //    if (velocity.magnitude > maxSpeed)
        //    {
        //        velocity.Normalize();
        //        velocity *= maxSpeed;
        //    }

        //    if (distance < 0.1f)
        //    {
        //        speed = 8;
        //    }
        //    else
        //    {
        //        speed = velocity.magnitude;
        //    }

        //    transform.Translate(velocity * Time.deltaTime, Space.World);
        //    transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(velocity), rotationDegreesPerSecond * Time.deltaTime);
        //}

        // arc arrive + lines
        //if (arrive && debug)
        //{
        //    Vector3 targetOffset = destination - transform.position;
        //    float distance = targetOffset.magnitude;
        //    float targetSpeed;

        //    if (distance < targetRadius)
        //    {
        //        targetSpeed = 8;
        //    }
        //    else
        //    {
        //        targetSpeed = maxSpeed * Mathf.Min(distance / satRadius, 1f);
        //    }

        //    Vector3 targetVelocity = targetOffset.normalized * targetSpeed;

        //    Vector3 acceleration = (targetVelocity - velocity) / timeToTarget;

        //    if (acceleration.magnitude > maxSpeed)
        //    {
        //        acceleration.Normalize();
        //        acceleration *= maxSpeed;
        //    }

        //    velocity += acceleration * Time.deltaTime;
        //    if (velocity.magnitude > maxSpeed)
        //    {
        //        velocity.Normalize();
        //        velocity *= maxSpeed;
        //    }

        //    if (distance < 0.1f)
        //    {
        //        speed = 0;
        //    }
        //    else
        //    {
        //        speed = velocity.magnitude;
        //    }

        //    transform.Translate(velocity * Time.deltaTime, Space.World);
        //    transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(velocity), rotationDegreesPerSecond * Time.deltaTime);

        //    // Calculate the predicted path
        //    Vector3 position = transform.position;
        //    Vector3 velocityCopy = velocity;
        //    List<Vector3> pathPoints = new List<Vector3>();
        //    pathPoints.Add(position);
        //    for (int i = 0; i < 10; i++)
        //    {
        //        // Calculate the next position and velocity
        //        Vector3 nextPosition = position + velocityCopy * Time.fixedDeltaTime + 0.5f * acceleration * Mathf.Pow(Time.fixedDeltaTime, 2f);
        //        Vector3 nextVelocity = velocityCopy + acceleration * Time.fixedDeltaTime;

        //        // Add the next position to the path
        //        pathPoints.Add(nextPosition);

        //        // Update the position and velocity for the next iteration
        //        position = nextPosition;
        //        velocityCopy = nextVelocity;
        //    }

        //    // Draw the arc lines
        //    for (int i = 0; i < pathPoints.Count - 1; i++)
        //    {
        //        UnityEngine.Debug.DrawLine(pathPoints[i], pathPoints[i + 1], Color.green, 0.2f);
        //    }
        //}

        // Kinematic flee
        if (flee)
        {
            if (GameObject.FindGameObjectWithTag("Chaser").GetComponent<NpcPlayer>().targetName != this.name)
            {
                flee = false;
                wander = true;
            }
            Vector3 velocity = transform.position - destination;
            velocity.Normalize();
            velocity *= maxSpeed;
            speed = maxSpeed;
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(velocity), rotationDegreesPerSecond * Time.deltaTime);
        }

        // Kinematic wander
        if (wander && this.tag != "Frozen")
        {
            if (targetName == "")
            {
                destination = new Vector3(Random.Range(0, 50), 0, Random.Range(0, 50));
            }
            else
            {
                GameObject target = GameObject.Find(targetName);
                destination = target.transform.position;
            }
            velocity = destination - transform.position;
            velocity.Normalize();
            velocity *= maxSpeed;
            speed = maxSpeed;
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(velocity), rotationDegreesPerSecond * Time.deltaTime);
        } 
    }


    // Find target depending on tag and distance
    void Target(string target)
    {
        // Use of kinematic arrive "pursue" for chosen target with appropriate tag
        foreach (GameObject opponent in GameObject.FindGameObjectsWithTag(target))
        {
            if (Vector3.Distance(transform.position, opponent.transform.position) < targetRadius)
            {
                targetName = opponent.name;
                distance = Vector3.Distance(transform.position, opponent.transform.position);
                destination = opponent.transform.position;
                arrive = true;
                flee = false;
                wander = false;
            }
            else
            {
                targetName = "";
                arrive = false;
                flee = false;
                wander = true;
            }
        }

        // Flee from tagged character if they are close enough
        if (this.tag == "Evader")
        {
            GameObject taggedOpponent = GameObject.FindGameObjectWithTag("Chaser");
            if (Vector3.Distance(transform.position, taggedOpponent.transform.position) < targetRadius)
            {
                distance = Vector3.Distance(transform.position, taggedOpponent.transform.position);
                destination = taggedOpponent.transform.position;
                arrive = false;
                flee = true;
                wander = false;
            }
            else
            {
                arrive = false;
                flee = false;
                wander = true;
            }
        }
    }

    // Change the tags on collision
    private void OnTriggerEnter(Collider collision)
    {
        // When we catch/freeze an evader
        if (collision.tag == "Evader" && this.tag == "Chaser")
        {
            targetName = "";
            collision.tag = "Frozen";
            arrive = false;
            flee = false;
            wander = true;
            collision.GetComponent<NpcPlayer>().arrive = false;
            collision.GetComponent<NpcPlayer>().flee = false;
            collision.GetComponent<NpcPlayer>().wander = false;
        }

        // When we free a Frozen evader
        if (collision.tag == "Frozen" && this.tag == "Evader")
        {
            foreach (GameObject NPCPlayer in GameObject.FindGameObjectsWithTag("Evader"))
            {
                NPCPlayer.GetComponent<NpcPlayer>().targetName = "";
            }
            collision.gameObject.tag = "Evader";
            StopCoroutine(BecomeChaserTimer());
            arrive = false;
            flee = false;
            wander = true;
            collision.GetComponent<NpcPlayer>().arrive = false;
            collision.GetComponent<NpcPlayer>().flee = false;
            collision.GetComponent<NpcPlayer>().wander = true;
        }
    }

    IEnumerator BecomeChaserTimer()
    {
        yield return new WaitForSeconds(maxFreezeTime);
        if (gameObject.CompareTag("Frozen"))
        {
            gameObject.tag = "Chaser";
            StartCoroutine(ChaseToken());
            coinChaser = true;          // becomes a coin chaser
        }
    }

    IEnumerator ChaseToken()
    {
        coinChaser = true;          // becomes a coin chaser
        yield return new WaitForSeconds(5f);     // will chase tokens for 5 seconds
        coinChaser = false;         // becomes a regular chaser
    }

    private void UpdateMaterial()
    {
        // Set the material based on the current tag of the NPC
        switch (gameObject.tag)
        {
            case "Evader":
                jointsRenderer.material = evaderMat;
                surfaceRenderer.material = evaderMat;
                break;
            case "Chaser":
                if(coinChaser)
                {
                    jointsRenderer.material = coinChaserMat;
                    surfaceRenderer.material = coinChaserMat;
                } 
                else
                {
                    jointsRenderer.material = chaserMat;
                    surfaceRenderer.material = chaserMat;
                }
                break;
            case "Frozen":
                jointsRenderer.material = frozenMat;
                surfaceRenderer.material = frozenMat;
                break;
        }
    }
}
