using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicController : MonoBehaviour
{
    public static MusicController instance;
    private void Awake()
    {
        if (instance == null)       // if there is no music starts music
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);        // ensures that the music is not duplicated by not restarting the music again once reloading the scene
        }
    }

}
