using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class TokenCollected : MonoBehaviour
{
    public int TokenQuantity { get; private set; }   // won't be modified by other scripts

    [SerializeField] private AudioSource tokenSoundEffect;           // Where the corresponding audio source component will be

    public UnityEvent<TokenCollected> OnTokenCollected;

    public void TokenScore()
    {
        TokenQuantity++;
        tokenSoundEffect.Play();             // Play the sound effect for the coin pickup
        OnTokenCollected.Invoke(this);       // Updates UI
    }
}
