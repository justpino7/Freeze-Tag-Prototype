using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Seek : MonoBehaviour
{
    public string targetTag = "Evader";
    public LayerMask obstacleMask;
    public float speed = 5f;
    public float coneAngle = 45f;
    public float coneDistance = 5f;

    private Transform target;

    void Start()
    {
        GameObject[] targets = GameObject.FindGameObjectsWithTag(targetTag);
        if (targets.Length > 0)
        {
            target = targets[Random.Range(0, targets.Length)].transform;
        }
    }

    void Update()
    {
        if (target == null)
        {
            GameObject[] targets = GameObject.FindGameObjectsWithTag(targetTag);
            if (targets.Length > 0)
            {
                target = targets[Random.Range(0, targets.Length)].transform;
            }
            return;
        }

        // Calculate direction to target
        Vector3 direction = (target.position - transform.position).normalized;

        // Calculate the cone shape by using dot product
        float coneHalfAngle = coneAngle / 2;
        float dotProduct = Vector3.Dot(transform.forward, direction);
        if (dotProduct < Mathf.Cos(coneHalfAngle * Mathf.Deg2Rad))
        {
            // Target is outside of the cone shape, rotate to face the target
            transform.rotation = Quaternion.LookRotation(direction);
        }
        else
        {
            // Target is within the cone shape, move towards the target while avoiding obstacles
            RaycastHit hit;
            if (Physics.Raycast(transform.position, direction, out hit, coneDistance, obstacleMask))
            {
                // Obstacle detected, rotate away from the obstacle
                Vector3 avoidanceDirection = Vector3.Cross(hit.normal, Vector3.up);
                transform.rotation = Quaternion.LookRotation(avoidanceDirection);
            }
            else
            {
                // No obstacle detected, move towards the target
                transform.Translate(direction * speed * Time.deltaTime);
            }
        }
    }
}
