using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionAvoidance : MonoBehaviour
{
    public float speed = 5.0f;
    public float avoidanceDistance = 2.0f;
    public float rayDistance = 5.0f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        // Get all colliders within a certain radius
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, avoidanceDistance);

        // Loop through all colliders to check for obstacles
        foreach (Collider hitCollider in hitColliders)
        {
            // Check if the collider is on the Wall layer
            if (hitCollider.gameObject.layer == LayerMask.NameToLayer("Wall"))
            {
                // Calculate the direction from the NPC to the obstacle
                Vector3 obstacleDirection = hitCollider.transform.position - transform.position;

                // Calculate the angle between the NPC's forward vector and the obstacle direction
                float angle = Vector3.Angle(transform.forward, obstacleDirection);

                // If the angle is less than 90 degrees, there is an obstacle in front of the NPC
                if (angle < 90.0f)
                {
                    // Cast a ray to see if there is a clear path to move towards the evader
                    RaycastHit hit;
                    if (!Physics.Raycast(transform.position, obstacleDirection.normalized, out hit, rayDistance))
                    {
                        // If there is no obstacle in the way, move towards the evader
                        rb.AddForce(obstacleDirection.normalized * speed);
                    }
                }
            }
            // Check if the collider has the tag "Evader"
            else if (hitCollider.gameObject.CompareTag("Evader"))
            {
                // Calculate the direction from the NPC to the evader
                Vector3 evaderDirection = hitCollider.transform.position - transform.position;

                // Cast a ray to see if there is a clear path to move towards the evader
                RaycastHit hit;
                if (!Physics.Raycast(transform.position, evaderDirection.normalized, out hit, rayDistance))
                {
                    // If there is no obstacle in the way, move towards the evader
                    rb.AddForce(evaderDirection.normalized * speed);
                }
            }
        }
    }
}
