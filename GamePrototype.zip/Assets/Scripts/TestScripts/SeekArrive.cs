using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeekArrive : MonoBehaviour
{
    public string evaderTag = "Evader";
    public float speed = 5f;
    public float stoppingDistance = 1f;
    public float slowingDistance = 10f;
    public float avoidDistance = 10f;
    public LayerMask obstacleMask;

    private GameObject evader;
    private Vector3 targetPosition;

    private void Start()
    {
        evader = FindClosestEvaderWithTag();
    }

    private void Update()
    {
        if (evader == null)
        {
            evader = FindClosestEvaderWithTag();
            return;
        }

        Vector3 direction = (targetPosition - transform.position).normalized;
        float distance = Vector3.Distance(transform.position, targetPosition);

        if (distance <= stoppingDistance)
        {
            evader = FindClosestEvaderWithTag();
            return;
        }
        else if (distance <= slowingDistance)
        {
            float targetSpeed = speed * (distance / slowingDistance);
            direction *= targetSpeed;
        }
        else
        {
            direction *= speed;
        }

        // Avoid obstacles in the wall layer
        RaycastHit hit;
        if (Physics.Raycast(transform.position, transform.forward, out hit, avoidDistance, obstacleMask))
        {
            // Calculate a vector perpendicular to the surface normal to move away from the obstacle
            Vector3 avoidanceDirection = Vector3.Cross(hit.normal, Vector3.up);
            direction += avoidanceDirection * speed;
        }

        transform.position += direction * Time.deltaTime;
    }

    private GameObject FindClosestEvaderWithTag()
    {
        GameObject[] evaders = GameObject.FindGameObjectsWithTag(evaderTag);
        GameObject closestEvader = null;
        float closestDistance = Mathf.Infinity;

        foreach (GameObject evader in evaders)
        {
            float distance = Vector3.Distance(transform.position, evader.transform.position);
            if (distance < closestDistance)
            {
                closestEvader = evader;
                closestDistance = distance;
            }
        }

        if (closestEvader != null)
        {
            targetPosition = closestEvader.transform.position;
        }

        return closestEvader;
    }

    private void OnCollisionEnter(Collision collision)
    {
        
    }
}
