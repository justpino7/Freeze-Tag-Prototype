using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WanderFlee : MonoBehaviour
{
    public string chaserTag = "Chaser";
    public LayerMask obstacleMask;
    public float wanderRadius = 5f;
    public float wanderDistance = 10f;
    public float wanderJitter = 1f;
    public float fleeDistance = 5f;
    public float speed = 5f;
    public float avoidanceForce = 2f;

    private bool isFleeing = false;
    private Transform chaser;
    private Vector3 wanderTarget;

    void Start()
    {
        // Set up the wander target
        wanderTarget = Random.insideUnitSphere * wanderRadius;
        wanderTarget += transform.position;
        wanderTarget.y = transform.position.y;

        // Find the nearest chaser
        GameObject[] chasers = GameObject.FindGameObjectsWithTag(chaserTag);
        if (chasers.Length > 0)
        {
            float closestDistance = Mathf.Infinity;
            foreach (GameObject chaserObject in chasers)
            {
                float distance = Vector3.Distance(transform.position, chaserObject.transform.position);
                if (distance < closestDistance)
                {
                    closestDistance = distance;
                    chaser = chaserObject.transform;
                }
            }
        }
    }

    void Update()
    {
        if (chaser != null)
        {
            // Calculate distance to chaser
            float distanceToChaser = Vector3.Distance(transform.position, chaser.position);

            if (distanceToChaser <= fleeDistance)
            {
                isFleeing = true;
            }
            else
            {
                isFleeing = false;
            }
        }

        if (isFleeing)
        {
            // Flee from the chaser
            Vector3 fleeDirection = transform.position - chaser.position;
            fleeDirection.y = 0f;

            // Avoid obstacles while fleeing
            RaycastHit hit;
            if (Physics.Raycast(transform.position, fleeDirection, out hit, fleeDirection.magnitude, obstacleMask))
            {
                Vector3 avoidanceDirection = Vector3.Cross(hit.normal, Vector3.up);
                transform.rotation = Quaternion.LookRotation(avoidanceDirection);
                transform.Translate(avoidanceDirection * avoidanceForce * Time.deltaTime, Space.World);
            }
            else
            {
                transform.rotation = Quaternion.LookRotation(fleeDirection);
                transform.Translate(fleeDirection.normalized * speed * Time.deltaTime, Space.World);
            }
        }
        else
        {
            // Wander behavior
            Vector3 randomOffset = Random.insideUnitSphere * wanderJitter;
            wanderTarget += randomOffset;
            wanderTarget.y = transform.position.y;

            Vector3 wanderDirection = wanderTarget - transform.position;

            // Avoid obstacles while wandering
            RaycastHit hit;
            if (Physics.Raycast(transform.position, wanderDirection, out hit, wanderDirection.magnitude, obstacleMask))
            {
                Vector3 avoidanceDirection = Vector3.Cross(hit.normal, Vector3.up);
                transform.rotation = Quaternion.LookRotation(avoidanceDirection);
                transform.Translate(avoidanceDirection * avoidanceForce * Time.deltaTime, Space.World);
            }
            else
            {
                transform.rotation = Quaternion.LookRotation(wanderDirection);
                transform.Translate(wanderDirection.normalized * speed * Time.deltaTime, Space.World);
            }

            if (Vector3.Distance(transform.position, wanderTarget) < 1f)
            {
                wanderTarget = Random.insideUnitSphere * wanderRadius;
                wanderTarget += transform.position;
                wanderTarget.y = transform.position.y;
            }
        }
    }
}
