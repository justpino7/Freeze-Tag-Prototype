using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking.Types;

public class NpcBehaviors : MonoBehaviour
{
    public enum NPCType { Chaser, Evader }

    public NPCType npcType;
    public LayerMask wallLayer;

    public float maxSpeed = 5f;
    public float arriveDistance = 1f;

    private Rigidbody rb;
    private Vector3 wanderTarget;
    private float wanderRadius = 2f;
    private float wanderDistance = 3f;
    private float wanderJitter = 1f;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        wanderTarget = Random.insideUnitSphere * wanderRadius;
    }

    private void FixedUpdate()
    {
        // Perform steering behavior based on the NPC type
        switch (npcType)
        {
            case NPCType.Chaser:
                Seek(FindClosestNPCWithTag("Evader").transform.position);
                break;
            case NPCType.Evader:
                if (CompareTag("Frozen"))
                {
                    return;
                }

                Evade(FindClosestNPCWithTag("Chaser").transform.position);
                break;
        }

        AvoidWalls();
        UpdateWanderTarget();
        Wander();
    }

    private void Seek(Vector3 target)
    {
        Vector3 desiredVelocity = (target - transform.position).normalized * maxSpeed;
        Vector3 steeringForce = desiredVelocity - rb.velocity;
        ApplyForce(steeringForce);
    }

    private void Flee(Vector3 target)
    {
        Vector3 desiredVelocity = (transform.position - target).normalized * maxSpeed;
        Vector3 steeringForce = desiredVelocity - rb.velocity;
        ApplyForce(steeringForce);
    }

    private void Evade(Vector3 target)
    {
        Vector3 targetDirection = target - transform.position;
        float lookAheadTime = targetDirection.magnitude / maxSpeed;
        Vector3 futurePosition = target + GameObject.FindGameObjectWithTag("Chaser").GetComponent<Rigidbody>().velocity * lookAheadTime;
        Flee(futurePosition);
    }

    private void UpdateWanderTarget()
    {
        wanderTarget += new Vector3(Random.Range(-1f, 1f) * wanderJitter, Random.Range(-1f, 1f) * wanderJitter, Random.Range(-1f, 1f) * wanderJitter);
        wanderTarget = wanderTarget.normalized * wanderRadius;
    }

    private void Wander()
    {
        Vector3 target = transform.position + transform.forward * wanderDistance + wanderTarget;
        Seek(target);
    }

    private void AvoidWalls()
    {
        RaycastHit hit;
        float avoidDistance = 3f;
        float avoidForce = 5f;
        Vector3 avoidVector = Vector3.zero;

        // Check for a wall in front of the NPC
        if (Physics.Raycast(transform.position, transform.forward, out hit, avoidDistance, wallLayer))
        {
            avoidVector += transform.right;
        }

        // Check for a wall to the right of the NPC
        if (Physics.Raycast(transform.position, transform.right, out hit, avoidDistance, wallLayer))
        {
            avoidVector += transform.up;
        }

        // Check for a wall to the left of the NPC
        if (Physics.Raycast(transform.position, -transform.right, out hit, avoidDistance, wallLayer))
        {
            avoidVector -= transform.up;
        }

        ApplyForce(avoidVector.normalized * avoidForce);
    }

    private void ApplyForce(Vector3 force)
    {
        rb.AddForce(force * Time.deltaTime, ForceMode.Force);
        rb.velocity = Vector3.ClampMagnitude(rb.velocity, maxSpeed);
    }

    private GameObject FindClosestNPCWithTag(string tag)
    {
        GameObject[] npcs = GameObject.FindGameObjectsWithTag(tag);
        GameObject closestNPC = null;
        float closestDistance = Mathf.Infinity;
        foreach (GameObject npc in npcs)
        {
            float distance = Vector3.Distance(transform.position, npc.transform.position);
            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestNPC = npc;
            }
        }

        return closestNPC;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (npcType == NPCType.Evader && collision.gameObject.CompareTag("Chaser"))
        {
            gameObject.tag = "Frozen";
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        if (npcType == NPCType.Evader && collision.gameObject.CompareTag("Frozen"))
        {
            collision.gameObject.tag = "Evader";
        }

    }
}
