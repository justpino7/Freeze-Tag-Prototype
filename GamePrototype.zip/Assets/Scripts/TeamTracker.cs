using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TeamTracker : MonoBehaviour
{
    public TextMeshProUGUI evaderCountText;
    public TextMeshProUGUI chaserCountText;

    private int evaderCount;
    private int chaserCount;

    private void Update()
    {
        evaderCount = GameObject.FindGameObjectsWithTag("Evader").Length;
        chaserCount = GameObject.FindGameObjectsWithTag("Chaser").Length;

        evaderCountText.text = (evaderCount-1).ToString();
        chaserCountText.text = chaserCount.ToString();
    }
}
