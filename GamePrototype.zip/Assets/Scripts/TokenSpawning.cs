using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TokenSpawning : MonoBehaviour
{
    public GameObject[] spawnPoints;    // store places where tokens can spawn
    public GameObject tokenPrefab;      // the token prefab to spawn
    public float minTimeBtwSpawns;
    public float maxTimeBtwSpawns;
    public int tokensToSpawn;      // number of tokens to spawn during the game

    private GameObject currentPoint;    // point to spawn the token
    private int lastIndex = -1;         // store last index used to avoid spawning at the same point twice
    private int tokensSpawned = 0;      // track number of tokens spawned
    private bool canSpawn = true;       // flag to allow a new token to be spawned

    private void Start()
    {
        SpawnToken();
    }

    private void Update()
    {
        // Check if there are any tokens in the scene
        GameObject token = GameObject.FindGameObjectWithTag("Token");
        if (token == null && tokensSpawned < tokensToSpawn)
        {
            // If the token has been picked up and we can spawn again, allow spawning
            canSpawn = true;
        }
    }

    private void SpawnToken()
    {
        if (canSpawn && tokensSpawned < tokensToSpawn)
        {
            // Choose a random token spawn point
            int index = Random.Range(0, spawnPoints.Length);
            // Make sure we don't spawn at the same point twice in a row
            while (index == lastIndex)
            {
                index = Random.Range(0, spawnPoints.Length);
            }
            lastIndex = index;
            currentPoint = spawnPoints[index];

            // Instantiate the token at the spawn point
            Instantiate(tokenPrefab, currentPoint.transform.position, Quaternion.identity);
            tokensSpawned++;
            canSpawn = false;  // Set flag to disallow spawning until current token is picked up
        }

        // Wait for some time and try again
        float timeBtwSpawns = Random.Range(minTimeBtwSpawns, maxTimeBtwSpawns);
        Invoke("SpawnToken", timeBtwSpawns);
    }
}
