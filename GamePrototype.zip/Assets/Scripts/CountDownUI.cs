using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class CountDownUI : MonoBehaviour
{
    public int countdownTime;           // can put more 5 mins or less
    public TMP_Text countdownDisplay;
    public TimeControl tc;

    private void Start()
    {
        tc.BeginGame();
        StartCoroutine(CountdownUntilEnd());
    }

    private void Update()
    {
      
    }

    IEnumerator CountdownUntilEnd()
    {
        yield return new WaitForSeconds(2f);
        while (countdownTime > 0)
        {
            countdownDisplay.text = countdownTime.ToString();
            yield return new WaitForSecondsRealtime(1f);            // waitseconds doesn't work with timeScale
            countdownTime--;
        }

        countdownDisplay.text = "Over";

        yield return new WaitForSeconds(3f);
        countdownDisplay.gameObject.SetActive(false);
        StartCoroutine(DisplayScore());
    }

    IEnumerator DisplayScore()
    {
        yield return new WaitForSecondsRealtime(3f);
    }
}
