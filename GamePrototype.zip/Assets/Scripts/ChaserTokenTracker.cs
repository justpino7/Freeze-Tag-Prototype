using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ChaserTokenTracker : MonoBehaviour
{
    public TMP_Text tokenCounterText; // Reference to the TMPro game object

    private int chaserTokenScore = 0;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Token"))
        {
            chaserTokenScore++;
            tokenCounterText.text = chaserTokenScore.ToString();
            //Destroy(other.gameObject); // Destroy the token object
        }
    }
}
