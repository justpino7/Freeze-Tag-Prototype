using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5.0f;
    public float avoidanceDistance = 2.0f;
    public float rayDistance = 5.0f;

    private Animator animator;
    private Rigidbody rb;

    void Start()
    {
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody>();

        StartCoroutine(UntagPlayer());
    }

    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(horizontal, 0, vertical);

        if (movement.magnitude != 0)
        {
            transform.rotation = Quaternion.LookRotation(movement);

            animator.SetBool("IsWalking", true);

            if (Input.GetKey(KeyCode.LeftShift))
            {
                animator.SetBool("IsRunning", true);
            }
            else
            {
                animator.SetBool("IsRunning", false);
            }
        }
        else
        {
            animator.SetBool("IsRunning", false);
            animator.SetBool("IsWalking", false);
        }

        // the check makes the player lose if he gets frozen
        //if (this.tag == "Frozen")
        //{
        //    SceneManager.LoadScene(2);
        //}
        // Perform collision avoidance for walls
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, avoidanceDistance, LayerMask.GetMask("Wall"));
        foreach (Collider hitCollider in hitColliders)
        {
            Vector3 obstacleDirection = hitCollider.transform.position - transform.position;
            float angle = Vector3.Angle(transform.forward, obstacleDirection);
            if (angle < 90.0f)
            {
                RaycastHit hit;
                if (!Physics.Raycast(transform.position, obstacleDirection.normalized, out hit, rayDistance, LayerMask.GetMask("Wall")))
                {
                    rb.AddForce(-obstacleDirection.normalized * speed);
                }
            }
        }
    }

    IEnumerator UntagPlayer()
    {
        yield return new WaitForSecondsRealtime(1f);
        gameObject.tag = "Evader";
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Frozen"))
        {
            other.tag = "Evader";
        }
    }
}
