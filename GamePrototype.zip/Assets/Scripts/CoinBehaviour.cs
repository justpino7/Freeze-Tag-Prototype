using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CoinBehaviour : MonoBehaviour
{
    public int rotationSpeed = 1;
    public int timer = 0;
    public TextMeshProUGUI chaserScoreText;
    public int playerTokenScore;
    public int chaserTokenScore;

    private void OnTriggerEnter(Collider other)
    {
       if (other.gameObject.layer == LayerMask.NameToLayer("Player")) 
        {
            CoinsCollected coinsCollected = other.GetComponent<CoinsCollected>();

            if (coinsCollected != null)         
            {
                coinsCollected.CoinScore();         // increment player score, play audio, update UI
                playerTokenScore++;
                Destroy(gameObject);    
            }
        }
       else if (other.CompareTag("Chaser"))
        {
            chaserTokenScore++;
            chaserScoreText.text = chaserTokenScore.ToString();
            Destroy(gameObject);

        }


    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(0, rotationSpeed, 0, Space.World);         // Coins rotate only in Y-axis
    }
}
