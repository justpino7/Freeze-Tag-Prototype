using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TokenUI : MonoBehaviour
{
    private TextMeshProUGUI tokenScore;

    void Start()
    {
        tokenScore = GetComponent<TextMeshProUGUI>();
    }

    public void UpdateTokenScore(TokenCollected tokenCollected)
    {
        tokenScore.text = tokenCollected.TokenQuantity.ToString();             // Changes the default text ("0") to the CoinQuantity variable from the CoinsCollected script
    }
}
