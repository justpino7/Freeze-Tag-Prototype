using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class CoinsCollected : MonoBehaviour
{
    public int CoinQuantity { get; private set; }   // won't be modified by other scripts

    [SerializeField] private AudioSource coinSoundEffect;           // Where the corresponding audio source component will be

    public UnityEvent<CoinsCollected> OnCoinCollected;

    public void CoinScore()
    {
        CoinQuantity++;
        coinSoundEffect.Play();             // Play the sound effect for the coin pickup
        OnCoinCollected.Invoke(this);       // Updates UI
    }

}
